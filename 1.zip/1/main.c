#include <stdio.h>
#include "add.h"
#include "sub.h"
#include "mux.h"
#include "div.h"
int main()
{
    int a = 20;
    int b = 10;
    printf("a = %d\n",a);
    printf("b = %d\n",b);
    printf("a + b = %d\n",add(a,b));
    printf("a - b = %d\n",sub(a,b));
    printf("a * b = %d\n",mux(a,b));
    printf("a / b = %d\n",div(a,b));
    return 0;
}
