#ifndef _SUB_H_
#define _SUB_H_
    extern int sub(int a,int b);
       #endif




