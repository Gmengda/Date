#ifndef _MUX_H_
   #define _MUX_H_
    extern int mux(int a,int b);
       #endif

