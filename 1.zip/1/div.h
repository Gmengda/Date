#ifndef _DIV_H_
   #define _DIV_H_
     extern int div(int a,int b);
       #endif

