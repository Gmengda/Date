#ifndef _ADD_H_
#define _ADD_H_
extern int add(int a,int b);
#endif
