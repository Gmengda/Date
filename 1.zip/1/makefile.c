tar=111
CC=gcc
ABCD=add \
     sub \
     mux \
     div \
     main
ABCDO=main.o add.o sub.o mux.o div.o
tar:ABCDO
	CC $^ -o $@
ABCDO:ABCD
	CC -c $^ -o $@
clean:
	rm add.o sub.o div.o mux.o main.o
